Application Title: Scheduling Assistant
Purpose: The provide a user friendly interface to schedule appointments for contacts and customers.
Author: Andrew Dahlstrom
E-Mail: adahls6@wgu.edu
Application Version: 1.0
Date: 9/18/2022
IDE: IntelliJ Community 2021.1.3 x 64
JDK: Java SE 17
JavaFX: JavaFX-SDK-17.0.1
MySQL Connector: mysql-connector-java-8.0.25

Instructions to run program: Download and unzip folder. Import src folder into preferred java IDE and navigate to main.
Run program from preferred IDE.

Additional Report: I chose to create a report which shows each contacts number of customers they have in each division (which the have customers in).
This report could be used to determine is one contact is stretched over too great of a geographic region.

